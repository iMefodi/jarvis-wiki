╔══════════════════════════════════════════════════════════════╗
║     LEGISLAȚIA CADASTRULUI — REPUBLICA MOLDOVA              ║
╚══════════════════════════════════════════════════════════════╝

STRUCTURA DOSARELOR:
──────────────────────
01_Legi_Cadastru\         ← Legi privind cadastrul bunurilor imobile
   LP1543_1998.htm        ← ✓ Legea cadastrului (text integral)
   [alte legi]            ← de descărcat de pe legis.md

02_Legi_Evaluare\         ← Legi privind evaluarea bunurilor imobile
03_Legi_Funciare\         ← Legislația funciară și sistemul de adrese
04_Hotariri_Guvern\       ← Hotărâri ale Guvernului
05_Ordine_ARFC_AGCC\      ← Ordine / Instrucțiuni tehnice
06_Geodezie_Cartografie\  ← Geodezie și cartografie
07_Date_Spatiale_INDS\    ← Date spațiale (INSPIRE)

INDEX.html                ← ⭐ CATALOG PRINCIPAL (deschideți în browser!)

──────────────────────────────────────────────
CUM SE DESCARCĂ ACTELE:
1. Deschideți INDEX.html în browser
2. Apăsați linkul „legis.md ↗" al actului dorit
3. Pe site-ul legis.md apăsați „PDF" sau salvați pagina (Ctrl+S)
4. Plasați fișierul salvat în dosarul corespunzător

──────────────────────────────────────────────
SURSE OFICIALE:
• legis.md                     — baza de legislație MJ
• agcc.gov.md/legislatia       — AGCC (geodezie, cadastru)
• ipcbi.gov.md/ro/legislatia   — IP Cadastrul Bunurilor Imobile
• inds.gov.md                  — date spațiale INSPIRE

──────────────────────────────────────────────
MODIFICĂRI IMPORTANTE 2023–2025:
• ARFC → AGCC (reorganizare, decembrie 2023)
• IP CBI creat din 03.01.2024 (servicii cadastrale)
• Noul Cod Funciar nr. 22/2024 (în vigoare din 07.03.2025)
• HG 201/2025 — noul regulament de înregistrare a drepturilor
• Ordin AGCC 52/2025 — abrogarea Instrucțiunii ARFC 112/2005
• Standardele IVSC (SEV 100-233) — în vigoare din 01.07.2025
